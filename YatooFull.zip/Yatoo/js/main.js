$(document).ready(function() {
	PopOver();
	ActionResult();
	SubmitSaveVote();
	ReadMoreInfoComapany();
	EditDetailCompany();
	AutoHeightTextArea();
	SignOutAccount();
	UploadImage();
});

function ActionResult(){
	var itemIdNum = $('.grid-result-left#result-left-itemnum').length;
	for(var i = 1; i <= itemIdNum; i++){
		VoteResult('.grid-result-left:nth-child(' + i + ')');	
	}
}

function VoteResult(resultID){
	$(resultID + ' .grid--result--left-item .like-star').hover(function(){
		var levelStar = $(this).index() + 1;

		switch(levelStar){
			case 1:{
				$(resultID + ' .grid--result--left-item .like-star').css('background','#c9c9c9');
				$(resultID + ' .grid--result--left-item .like-star:nth-child(1)').css('background','#fff200');
			};break;
			case 2:{
				$(resultID + ' .grid--result--left-item .like-star').css('background','#c9c9c9');
				for(var i = 1; i <= 2; i++){
					$(resultID + ' .grid--result--left-item .like-star:nth-child(' + i + ')').css('background','#fff200');
				}
			};break;
			case 3:{
				$(resultID + ' .grid--result--left-item .like-star').css('background','#c9c9c9');
				for(var i = 1; i <= 3; i++){
					$(resultID + ' .grid--result--left-item .like-star:nth-child(' + i + ')').css('background','#fff200');
				}
			};break;
			case 4:{
				$(resultID + ' .grid--result--left-item .like-star').css('background','#c9c9c9');
				for(var i = 1; i <= 4; i++){
					$(resultID + ' .grid--result--left-item .like-star:nth-child(' + i + ')').css('background','#fff200');
				}
			};break;
			case 5:{
				$(resultID + ' .grid--result--left-item .like-star').css('background','#c9c9c9');
				for(var i = 1; i <= 5; i++){
					$(resultID + ' .grid--result--left-item .like-star:nth-child(' + i + ')').css('background','#fff200');
				}
			};break;
			default: break;
		};
	});

	$(resultID + ' .grid--result--left-item .like-star').click(function(){
		$(resultID + ' .grid--result--left-item  span.grid--result--left--item-accept').css('display','block');
		$(resultID + ' .grid--result--left-item  span.grid--result--left--item-cancel').css('display','block');
		$(resultID + ' .grid--result--left-item  span.grid--result--left--item-numlike').css('display','none');
		if($(window).width() <= 568){
			$('.grid--result--left--item-like').css('margin-bottom','24px');
		}
	});

	$(resultID + ' .grid--result--left-item  span.grid--result--left--item-cancel').click(function(){
		$(resultID + ' .grid--result--left-item  span.grid--result--left--item-accept').css('display','none');
		$(resultID + ' .grid--result--left-item  span.grid--result--left--item-cancel').css('display','none');
		$(resultID + ' .grid--result--left-item  span.grid--result--left--item-numlike').css('display','block');
		if($(window).width() <= 568){
			$('.grid--result--left--item-like').css('margin-bottom','0');
		}
	});
}

function SubmitSaveVote(){
	$('button.btn.btn-default.btn-save-submit').click(function(){
		if($(this).hasClass('save')){
			$(this).removeClass('save');
		}else{
			$(this).addClass('save');
		}
	});
}

function PopOver(){
	$('[data-toggle="popover"]').popover(); 
}

function ReadMoreInfoComapany(){
	/*max string of description is '200'*/
	var maxLengthDesktop = $('.grid-detailcompay-description.desktop').text().length - 10;
	var maxLenghthMobile = $('.grid-detailcompay-description.mobile').text().length - 10;

	if(maxLengthDesktop <= 200 || maxLenghthMobile <= 200){
		$('.grid-detailcompay-readmore').css('display','none');
		$('.grid-detailcompay-resetdesp').css('display','none');
	}else{
		$('.grid-detailcompay-readmore').click(function(){
			$('.grid-detailcompay-description').css('-webkit-line-clamp','initial');
			$(this).css('display','none');
			$('.grid-detailcompay-resetdesp').css('display','block');
			$('.grid-detailcompay-resetdesp').css('margin-left','0');
		});

		$('.grid-detailcompay-resetdesp').click(function(){
			$('.grid-detailcompay-description').css('-webkit-line-clamp','3');
			$(this).css('display','none');
			$('.grid-detailcompay-readmore').css('display','block');
		});
	}
}

var activeFlag = true;
var activeEquiqe= true;
var activeCataLeft = true;
var activeCataRight = true;
var activeMain = true;

function EditDetailCompany(){
	$('.btn-modifire-submit').click(function(){
		ActionModifire();
		$(this).css('display','none');
	});

	$('.btn-terminer-submit').click(function(){
		ActionTerminer();
		$(this).css('display','none');
	});

	$('.btn-valider-submit').click(function(){
		ActionTerminer();
	});

	/*Edit main block*/
	$('.grid-detailcompay-editarea.main-part').click(function(){
		if(activeMain == false){
			activeMain = true;
			$('.grid-detailcompay-editimage-area.main-part').css('display','none');
			$('.grid-detailcompay-delimage-area.main-part').css('display','none');
			$('.grid--detailcompay--info-name').attr('disabled', 'disabled');
			$('.grid--detailcompay--info-name').css('border','none');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.position .main-part').attr('disabled', 'disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.position .main-part').css('border','none');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.mail .main-part').attr('disabled', 'disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.mail .main-part').css('border','none');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.phone .main-part').attr('disabled', 'disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.phone .main-part').css('border','none');
			$('.grid-detailcompay-social .grid--detailcompay--social-area > p .main-part').attr('disabled', 'disabled');
			$('.grid-detailcompay-social .grid--detailcompay--social-area > p .main-part').css('border','none');
			$('.detailcompay-description-edit').css('display','none');
			$('.grid-detailcompay-description.desktop').css('display','block');
			$('.grid-detailcompay-readmore').css('display','block');
		}else{
			$('.grid-detailcompay-editimage-area.main-part').css('display','block');
			$('.grid-detailcompay-delimage-area.main-part').css('display','block');
			$('.grid--detailcompay--info-name').removeAttr('disabled');
			$('.grid--detailcompay--info-name').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.position .main-part').removeAttr('disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.position .main-part').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.mail .main-part').removeAttr('disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.mail .main-part').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.phone .main-part').removeAttr('disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.phone .main-part').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-social .grid--detailcompay--social-area > p .main-part').removeAttr('disabled');
			$('.grid-detailcompay-social .grid--detailcompay--social-area > p .main-part').css('border','1px solid #e5e5e5');
			$('.detailcompay-description-edit').css('display','block');
			$('.grid-detailcompay-description.desktop').css('display','none');
			$('.grid-detailcompay-readmore').css('display','none');
			activeMain = false;
		}
	});


	/*Edit active block*/
	$('.grid-detailcompay-editarea.active-part').click(function(){
		if(activeFlag == false){
			activeFlag = true;
			$('.grid-detailcompay-editimage-area.active-part').css('display','none');
			$('.grid-detailcompay-delimage-area.active-part').css('display','none');
			$('.grid-detailcompay-title.active').attr('disabled', 'disabled');
			$('.grid-detailcompay-title.active').css('border','none');
			$('.grid-detailcompany-description.active-part').attr('disabled', 'disabled');
			$('.grid-detailcompany-description.active-part').css('border','none');
			$('.grid-detailcompay-activetitle').attr('disabled', 'disabled');
			$('.grid-detailcompay-activedes').attr('disabled', 'disabled');
			$('.grid-detailcompay-activetitle').css('border','none');
			$('.grid-detailcompay-activedes').css('border','none');
			$('.item-slider.item-slider-newbig').css('display','none');
		}else{
			$('.grid-detailcompay-editimage-area.active-part').css('display','block');
			$('.grid-detailcompay-delimage-area.active-part').css('display','block');
			$('.grid-detailcompay-title.active').removeAttr('disabled');
			$('.grid-detailcompay-title.active').css('border','1px solid #e5e5e5');
			$('.grid-detailcompany-description.active-part').removeAttr('disabled');
			$('.grid-detailcompany-description.active-part').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-activetitle').removeAttr('disabled');
			$('.grid-detailcompay-activedes').removeAttr('disabled');
			$('.grid-detailcompay-activetitle').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-activedes').css('border','1px solid #e5e5e5');
			$('.item-slider.item-slider-newbig').css('display','block');
			activeFlag = false;
		}
	});

	/*Edit equique block*/
	$('.grid-detailcompay-editarea.equiqe-part').click(function(){
		if(activeEquiqe == false){
			activeEquiqe = true;
			$('.grid-detailcompay-editimage-area.equiqe').css('display','none');
			$('.grid-detailcompay-delimage-area.equiqe').css('display','none');
			$('.grid-detailcompay-equipename').attr('disabled', 'disabled');
			$('.grid-detailcompay-equipejob').attr('disabled', 'disabled');
			$('.grid-detailcompay-title.equipe').attr('disabled', 'disabled');
			$('.grid-detailcompay-equipename').css('border', 'none');
			$('.grid-detailcompay-equipejob').css('border', 'none');
			$('.grid-detailcompay-title.equipe').css('border','none');
			$('.grid-detailcompany-description.equiqe-part').attr('disabled', 'disabled');
			$('.grid-detailcompany-description.equiqe-part').css('border','none');
			$('.item-slider.item-slider-newbig.equipe').css('display','none');
		}else{
			$('.grid-detailcompay-editimage-area.equiqe').css('display','block');
			$('.grid-detailcompay-delimage-area.equiqe').css('display','block');
			$('.grid-detailcompay-equipename').removeAttr('disabled');
			$('.grid-detailcompay-equipejob').removeAttr('disabled');
			$('.grid-detailcompay-title.equipe').removeAttr('disabled');
			$('.grid-detailcompay-equipename').css('border', '1px solid #e5e5e5');
			$('.grid-detailcompay-equipejob').css('border', '1px solid #e5e5e5');
			$('.grid-detailcompay-title.equipe').css('border','1px solid #e5e5e5');
			$('.grid-detailcompany-description.equiqe-part').removeAttr('disabled');
			$('.grid-detailcompany-description.equiqe-part').css('border','1px solid #e5e5e5');
			$('.item-slider.item-slider-newbig.equipe').css('display','block');
			activeEquiqe = false;
		}
	});

	/*Edit catalogue block*/
	$('.row .col-md-6:nth-child(1) .grid-detailcompay-right.grid-detailcompay-desktop.mobile .grid-detailcompay-editarea.catalogue').click(function(){
		if(activeCataLeft == false){
			$('.grid-detailcompay-editimage-area.catalogue.catalogue-left').css('display','none');
			$('.grid-detailcompay-delimage-area.catalogue.catalogue-left').css('display','none');
			$('.grid-detailcompay-title.catalogue-left').attr('disabled', 'disabled');
			$('.grid-detailcompany-description.catalogue-left').attr('disabled', 'disabled');
			$('.grid-detailcompany-description.catalogue-left').css('border', 'none');
			$('.grid-detailcompay-title.catalogue-left').css('border', 'none');
			$('.grid-detailcompay-cataloguetitle.catalogue-left').attr('disabled', 'disabled');
			$('.grid-detailcompay-cataloguetitle.catalogue-left').css('border','none');
			$('.grid-detailcompay-cataloguedes.catalogue-left').attr('disabled', 'disabled');
			$('.grid-detailcompay-cataloguedes.catalogue-left').css('border','none');
			$('.slider.slider-catalogue .item-slider-new.left').css('display','none');
			activeCataLeft = true;
		}else{
			$('.grid-detailcompay-editimage-area.catalogue.catalogue-left').css('display','block');
			$('.grid-detailcompay-delimage-area.catalogue.catalogue-left').css('display','block');
			$('.grid-detailcompay-title.catalogue-left').removeAttr('disabled');
			$('.grid-detailcompany-description.catalogue-left').removeAttr('disabled');
			$('.grid-detailcompay-title.catalogue-left').css('border', '1px solid #e5e5e5');
			$('.grid-detailcompany-description.catalogue-left').css('border', '1px solid #e5e5e5');
			$('.grid-detailcompay-cataloguetitle.catalogue-left').removeAttr('disabled');
			$('.grid-detailcompay-cataloguetitle.catalogue-left').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-cataloguedes.catalogue-left').removeAttr('disabled');
			$('.grid-detailcompay-cataloguedes.catalogue-left').css('border','1px solid #e5e5e5');
			$('.slider.slider-catalogue .item-slider-new.left').css('display','block');
			activeCataLeft = false;
		}
	});
	$('.row .col-md-6:nth-child(2) .grid-detailcompay-right.grid-detailcompay-desktop.mobile .grid-detailcompay-editarea.catalogue').click(function(){
		if(activeCataRight == false){
			$('.grid-detailcompay-editimage-area.catalogue.catalogue-right').css('display','none');
			$('.grid-detailcompay-delimage-area.catalogue.catalogue-right').css('display','none');
			$('.grid-detailcompay-title.catalogue-right').attr('disabled', 'disabled');
			$('.grid-detailcompany-description.catalogue-right').attr('disabled', 'disabled');
			$('.grid-detailcompany-description.catalogue-right').css('border', 'none');
			$('.grid-detailcompay-title.catalogue-right').css('border', 'none');
			$('.grid-detailcompay-cataloguetitle.catalogue-right').attr('disabled', 'disabled');
			$('.grid-detailcompay-cataloguetitle.catalogue-right').css('border','none');
			$('.grid-detailcompay-cataloguedes.catalogue-right').attr('disabled', 'disabled');
			$('.grid-detailcompay-cataloguedes.catalogue-right').css('border','none');
			$('.slider.slider-catalogue .item-slider-new.right').css('display','none');
			activeCataRight = true;
		}else{
			$('.grid-detailcompay-editimage-area.catalogue.catalogue-right').css('display','block');
			$('.grid-detailcompay-delimage-area.catalogue.catalogue-right').css('display','block');
			$('.grid-detailcompay-title.catalogue-right').removeAttr('disabled');
			$('.grid-detailcompany-description.catalogue-right').removeAttr('disabled');
			$('.grid-detailcompay-title.catalogue-right').css('border', '1px solid #e5e5e5');
			$('.grid-detailcompany-description.catalogue-right').css('border', '1px solid #e5e5e5');
			$('.grid-detailcompay-cataloguetitle.catalogue-right').removeAttr('disabled');
			$('.grid-detailcompay-cataloguetitle.catalogue-right').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-cataloguedes.catalogue-right').removeAttr('disabled');
			$('.grid-detailcompay-cataloguedes.catalogue-right').css('border','1px solid #e5e5e5');
			$('.slider.slider-catalogue .item-slider-new.right').css('display','block');
			$('.grid-detailcompay-editimage-area.catalogue.catalogue-new').css('display','block');
			activeCataRight = false;
		}
	});
}

function ActionModifire(){
	$('.grid-detailcompay-editarea').css('display','block');
	$('.grid-detailcompay-editinfoarea').css('display','block');
	$('.btn-terminer-submit').css('display','block');
	$('.grid-detailcompay-savesubmit.modifier').css('display','inherit');
	$('.grid-detailcompay-savesubmit.modifier').css('margin-left','-15px');
	$('.grid-detailcompay-savesubmit.modifier').css('margin-right','-15px');
	$('.modifier-catalogue').css('display','block');
}

function ActionTerminer(){
	$('.grid-detailcompay-editarea').css('display','none');
	$('.grid-detailcompay-editinfoarea').css('display','none');
	$('.btn-modifire-submit').css('display','block');
	$('.grid-detailcompay-savesubmit.modifier').css('display','table');
	$('.grid-detailcompay-savesubmit.modifier').css('margin','auto');
	$('.modifier-catalogue').css('display','none');
	$('.grid-detailcompay-delimage-area').css('display','none');
	$('.grid-detailcompay-delimage-area.equiqe').css('display','none');
	$('.grid-detailcompay-editimage-area').css('display','none');
	$('.grid-detailcompay-editimage-area.equiqe').css('display','none');

	$('.grid-detailcompay-equipename').attr('disabled', 'disabled');
	$('.grid-detailcompay-equipejob').attr('disabled', 'disabled');
	$('.grid-detailcompay-equipename').css('border', 'none');
	$('.grid-detailcompay-equipejob').css('border', 'none');
	$('.grid-detailcompay-title.equipe').attr('disabled', 'disabled');
	$('.grid-detailcompay-title.equipe').css('border','none');
	$('.grid-detailcompany-description.equiqe-part').attr('disabled', 'disabled');
	$('.grid-detailcompany-description.equiqe-part').css('border','none');

	$('.grid-detailcompay-title.catalogue-left').css('border', 'none');
	$('.grid-detailcompany-description.catalogue-left').css('border', 'none');
	$('.grid-detailcompay-title.catalogue-left').attr('disabled', 'disabled');
	$('.grid-detailcompany-description.catalogue-left').attr('disabled', 'disabled');
	$('.grid-detailcompay-cataloguetitle.catalogue-left').attr('disabled', 'disabled');
	$('.grid-detailcompay-cataloguedes.catalogue-left').attr('disabled', 'disabled');
	$('.grid-detailcompay-cataloguetitle.catalogue-left').css('border','none');
	$('.grid-detailcompay-cataloguedes.catalogue-left').css('border','none');
	$('.slider.slider-catalogue .item-slider-new.left').css('display','none');
	$('.slider.slider-catalogue .item-slider-new.right').css('display','none');

	$('.grid-detailcompay-title.catalogue-right').attr('disabled', 'disabled');
	$('.grid-detailcompany-description.catalogue-right').attr('disabled', 'disabled');
	$('.grid-detailcompany-description.catalogue-right').css('border', 'none');
	$('.grid-detailcompay-title.catalogue-right').css('border', 'none');
	$('.grid-detailcompay-cataloguetitle.catalogue-right').attr('disabled', 'disabled');
	$('.grid-detailcompay-cataloguetitle.catalogue-right').css('border','none');
	$('.grid-detailcompay-cataloguedes.catalogue-right').attr('disabled', 'disabled');
	$('.grid-detailcompay-cataloguedes.catalogue-right').css('border','none');

	$('.grid-detailcompay-title.active').attr('disabled', 'disabled');
	$('.grid-detailcompay-title.active').css('border','none');
	$('.grid-detailcompany-description.active-part').attr('disabled', 'disabled');
	$('.grid-detailcompany-description.active-part').css('border','none');
	$('.grid-detailcompay-activetitle').attr('disabled', 'disabled');
	$('.grid-detailcompay-activedes').attr('disabled', 'disabled');
	$('.grid-detailcompay-activetitle').css('border','none');
	$('.grid-detailcompay-activedes').css('border','none');
	$('.item-slider.item-slider-newbig').css('display','none');

	$('.grid--detailcompay--info-name').attr('disabled', 'disabled');
	$('.grid--detailcompay--info-name').css('border','none');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.position .main-part').attr('disabled', 'disabled');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.position .main-part').css('border','none');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.mail .main-part').attr('disabled', 'disabled');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.mail .main-part').css('border','none');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.phone .main-part').attr('disabled', 'disabled');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.phone .main-part').css('border','none');
	$('.grid-detailcompay-social .grid--detailcompay--social-area > p .main-part').attr('disabled', 'disabled');
	$('.grid-detailcompay-social .grid--detailcompay--social-area > p .main-part').css('border','none');
	$('.detailcompay-description-edit').css('display','none');
	$('.grid-detailcompay-description.desktop').css('display','block');
	$('.grid-detailcompay-readmore').css('display','block');
}

function AutoHeightTextArea(){
	auto_grow($('.grid-detailcompany-description.catalogue-left'));
	auto_grow($('.grid-detailcompay-cataloguetitle.catalogue-left'));
	auto_grow($('.grid-detailcompay-cataloguedes.catalogue-left'));
	auto_grow($('.grid-detailcompany-description.catalogue-right'));
	auto_grow($('.grid-detailcompay-cataloguetitle.catalogue-right'));
	auto_grow($('.grid-detailcompay-cataloguedes.catalogue-right'));
	auto_grow($('.grid--detailcompay--info-name'));
	auto_grow($('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.position .main-part'));
	auto_grow($('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.mail .main-part'));
	auto_grow($('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.phone .main-part'));
	auto_grow($('.grid-detailcompany-description.active-part'));
	auto_grow($('.grid-detailcompany-description.equiqe-part'));
}
function auto_grow($element) {
	var $element = 
    $($element).keyup(function(){
    	var heightTextarea = 5;
    	heightTextarea = $(this).prop('scrollHeight') + 'px';
    	console.log(heightTextarea);
    	$(this).css('height', heightTextarea);
    });
}

var signInFlag = true;
function SignOutAccount(){
	$('.sign-out-account').click(function(){
		if($('.dropdown.open-signin').hasClass('open')){
			$(this).removeClass('open');
			alert('Sign Out Account');
			signInFlag = false;
		}
		if($('.header-group-icon').hasClass('signin')){
			$('.header-group-icon').removeClass('signin');
		}
		if($('.header-item.dropdown-toggle.dropdown-toggle-signin').hasClass('signin')){
			$('.header-item.dropdown-toggle.dropdown-toggle-signin').removeClass('signin');
		}
		if($('.header--icon-account').hasClass('signin')){
			$('.header--icon-account').removeClass('signin');
		}
		$('.header-item.dropdown-toggle.dropdown-toggle-signin:nth-child(2)').text('Connexion Inscription');
		$('.navbar-default .navbar-collapse').css('min-height','inherit');
	});

	$('.dropdown.open-signin').click(function(){
		if(signInFlag == false){
			$(this).removeClass('open');
			$('.dropdown-toggle-signin').attr('data-toggle','');
		}
	});
}

function UploadImage(){
	/*Status of Upload Image*/
	$('.inputfile-area').click(function(){
		$('#file').change(function(){
			$('.profile-add-image-btn').text('Uploaded');
		});
	});

	/*Status of Remove Image*/
	$('.btn-remove-img').click(function(){
		$('.profile-add-image-btn').text('Cliquer pour télécharger/ modifier');
		$('#file').val() = null;
	})
}