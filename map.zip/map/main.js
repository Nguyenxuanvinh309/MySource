$(document).ready(function(){
	CreatMap();
});

function CreatMap(){
	google.charts.load('current', {
		'packages':['corechart'],
        // Note: you will need to get a mapsApiKey for your project.
        // See: https://developers.google.com/chart/interactive/docs/basic_load_libs#load-settings
        'mapsApiKey': 'AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'
    });
	google.charts.setOnLoadCallback(drawRegionsMap);
	drawRegionsMap();
}

function drawRegionsMap() {
	var data = google.visualization.arrayToDataTable([
		['Province', 'Successful Deliveries'],
		['FR-A', 'Alsace'],
		['FR-B', 'Aquitaine'],
		['FR-C', 'Auvergne'],
		['FR-D', 'Burgundy'],
		['FR-E', 'Brittany'],
		['FR-F', 'Centre-Val de Loire'],
		['FR-G', 'Champagne-Ardenne'],
		['FR-H','Corsica'],
		['FR-I','Franche-Comté'],
		['FR-J', 'Île-de-France'],
		['FR-K', 'Languedoc-Roussillon'],
		['FR-L', 'Limousin'],
		['FR-M', 'Lorraine'],
		['FR-N', 'Midi-Pyrénées'],
		['FR-O', 'Nord-Pas-de-Calais'],
		['FR-P', 'Lower Normandy'],
		['FR-Q', 'Upper Normandy'],
		['FR-R','Pays de la Loire'],
		['FR-S','Picardy'],
		['FR-T','Poitou-Charentes'],
		['FR-U',"Provence-Alpes-Côte d'Azur"],
		['FR-V','Rhône-Alpes']
		]);

	var chart = new google.visualization.GeoChart(
		document.getElementById('regions_div')
		);

	function myClickHandler(){
		var selection = chart.getSelection();
		var message = '';
		for (var i = 0; i < selection.length; i++) {
			var item = selection[i];
			if (item.row != null) {
				message = item.row;
			}
		}
		alert('You selected: ' + message);
	}
	google.visualization.events.addListener(chart, 'select', myClickHandler);

	var options = { 
		datalessRegionColor: '#123456',
		region: 'FR',
		resolution: 'provinces',
		defaultColor: 'blue',
		dataMode: 'regions',
		keepAspectRatio: true,
		tooltip: { 
			isHtml:true,
            // trigger: 'both' 
        },
        width:1200,
        height:500
    };
    chart.draw(data, options);
}