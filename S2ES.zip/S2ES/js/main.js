$(document).ready(function(){
	/*Active Item Press*/
	ActiveResultPress();
	DescriptionResult();
});

/*Active Item Press*/
function ActiveResultPress(){
	/*Recherche par catégorie: Item active*/
	ActiveDropDownList('une-famille');
	ActiveDropDownList('unesous-famille');
	ActiveDropDownList('une-marque');
    
    /*Recherche par marque: Item active*/
	ActiveresultParPage();
}

function ActiveDropDownList(nameDropName){
	if($('.result-select.'+nameDropName+' li').length > 0){
		$('.result-select.'+nameDropName+' li').click(function(){
			if($('.result-select.'+nameDropName+' li').is('.active')){
				$('.result-select.'+nameDropName+' li').removeClass('active');
			}

			$(this).toggleClass('active');
			$(this).parent().parent().children('.dropdown-toggle').html('<span>'+$(this).text()+'</span>');
			$(this).parent().parent().children('.dropdown-toggle').append('<span class="dropdown-symbol"></span>');
		});
	}
}

function ActiveresultParPage(){
	$('.result-par-pagegroup ul li').click(function(){
		if($('.result-par-pagegroup ul li').is('.active')){
			$('.result-par-pagegroup ul li').removeClass('active');
			$(this).toggleClass('active');
		}
	});
}

var toggleShow = true;
function DescriptionResult(){
	// if($('.result-des-area').length > 0){
	// 	alert($('.result-des-area').width());
	// }
	if($('.result-item-row').length > 0){
		for(var i = 1; i <= $('.result-item-row').length; i++){
			if($('.result-item-row:nth-child('+i+')').height() > 180){
				console.log(i);
				$('.result-item-row:nth-child('+i+') .result-des-area').addClass('show-more');
			}
		}

		$('.result-des-area.show-more').after().click(function(){
			if(toggleShow === true){
				$(this).removeClass('show-more').hide();
				$(this).slideToggle( "slow" );
				$(this).append('<span class="less-more">Less More</span>');
				toggleShow = false;
			}else{
				$('.result-des-area .less-more').remove();
				$(this).addClass('show-more');
				toggleShow = true;
			}
		});
	}
}