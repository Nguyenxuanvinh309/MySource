import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home'
import DataBinding from '@/components/DataBinding'
import DataMethod from '@/components/DataMethod'
import Event from '@/components/Event'
import EventModifier from '@/components/EventModifier'
import HelloWorld from '@/components/HelloWorld'
import KeyboardEvents from '@/components/KeyboardEvents'
import TwoWayDataBinding from '@/components/TwoWayDataBinding'
import Computed from '@/components/Computed'
import DynamicCSS from '@/components/DynamicCSS'
import Conditionals from '@/components/Conditionals'
import Looping from '@/components/Looping'
import NotFound from '@/components/NotFound'

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {path: '/', name: 'Home', component: Home},
    {path: "*", name: 'NotFound', component: NotFound },
    {path: '/binding', name: 'DataBinding', component: DataBinding},
    {path: '/datamethod', name: 'DataMethod', component: DataMethod},
    {path: '/event', name: 'Event', component: Event},
    {path: '/event-modifier', name: 'EventModifier', component: EventModifier},
    {path: '/hello', name: 'HelloWorld', component: HelloWorld},
    {path: '/keyboard', name: 'KeyboardEvents', component: KeyboardEvents},
    {path: '/two-way-binding', name: 'TwoWayDataBinding', component: TwoWayDataBinding},
    {path: '/computed', name: 'Computed', component: Computed},
    {path: '/dynamic-css', name: 'DynamicCSS', component: DynamicCSS},
    {path: '/conditional', name: 'Conditionals', component: Conditionals},
    {path: '/looping', name: 'Looping', component: Looping}
  ]
})
