<template>
  <div class="hello">
    <h1>404</h1>
    <p>Not Found Page</p>
  </div>
</template>

<script>
export default {
  name: 'NotFound',
  data () {
    return {
      msg: 'Not Found Page'
    }
  }
}
</script>

