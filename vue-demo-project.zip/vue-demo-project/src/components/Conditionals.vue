<template>
  <div>
    <h1>{{msg}}</h1>
    <h2 v-if="nameflag">{{name}}</h2>
    <h2 v-if="jobflag">{{job}}</h2>
    <h2 v-if="oldflag">{{old}}</h2>

    <transition name="fade">
      <h2 v-show="allflag">{{name}} - {{job}} - {{old}}</h2>
    </transition>

    <button v-on:click="nameflag = !nameflag" type="input">Name</button>
    <button v-on:click="jobflag = !jobflag" type="input">Job</button>
    <button v-on:click="oldflag = !oldflag" type="input">Age</button>
    <button v-on:click="allflag = !allflag" type="input">Show All</button>
  </div>
</template>

<script>
export default {
  name: 'Conditionals',
  data () {
    return {
      msg: 'Conditionals',
      name: 'Kai',
      job: 'Dev',
      old: 23,
      nameflag: false,
      jobflag: false,
      oldflag: false,
      allflag: true
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
.information-area{
  font-size: 32px;
  text-transform: uppercase;
}
.information-area li{
  display: list-item;
  font-size: 20px;
}
a, span {
  color: #42b983;
}
.color-text, .colortext{
  color: #42b983; 
}
.colortext{
  font-size: 20px;
  font-weight: 600;
}
.bcktext{
  background: #42b983;
  color: #fff;
  display: table;
  margin: auto;
  padding: 10px 20px;
  margin-top: 5px;
  margin-bottom: 5px;
  cursor: pointer;
}
.bcktext:hover{
  background: #2c3e50;
  color: #fff;

  transition: 1s;
  -webkit-transition: 1s;
  -moz-transition: 1s;
  -ms-transition: 1s;
  -o-transition: 1s;
}
.group-data, .group-button{
  margin-bottom: 10px;
}
.group-data-item{
  margin-bottom: 5px;
}

.available, .nearby{
  background: #42b983;
  color: #fff;
  display: table;
  margin: auto;
  padding: 10px 20px;
  margin-top: 5px;
  margin-bottom: 5px;
  cursor: pointer;
  font-weight: bold;
  font-size: 20px;

  transition: 1s;
  -webkit-transition: 1s;
  -moz-transition: 1s;
  -ms-transition: 1s;
  -o-transition: 1s;
}

.nearby{
  background: red;

  transition: 1s;
  -webkit-transition: 1s;
  -moz-transition: 1s;
  -ms-transition: 1s;
  -o-transition: 1s;
}

.fade-enter-active, .fade-leave-active {
  transition: opacity .8s;
  -webkit-transition: opacity .8s;
  -o-transition: opacity .8s;
  -ms-transition: opacity .8s;
  -moz-transition: opacity .8s;
}

.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}

</style>
