<template>
  <div>
    <h1>{{msg}}</h1>
    <p>Age: {{age}}</p>
    <button type="submit" @click="add(1)">Add age</button>
    <button type="submit" v-on:click="subtract(1)">Subtract age</button>
    <button type="submit" @dblclick="add(10)">Add age 10</button>
    <button type="submit" v-on:dblclick="subtract(10)">Subtract age 10</button>
    <div id="canvas" v-on:mousemove="updatePostion">{{x}},{{y}}</div>
  </div>
</template>

<script>
export default {
  name: 'Event',
  data () {
    return {
      msg: 'Event',
      age: 23,
      x: 0,
      y: 0
    }
  },
  methods:{
    add: function(age){
      this.age += age;
    },

    subtract: function(age){
      this.age -= age;
    },

    updatePostion: function(event){
      this.x = event.movementX;
      this.y = event.movementY;
    } 
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
a, span {
  color: #42b983;
}
.color-text{
  color: #42b983; 
}
.group-data{
  margin-bottom: 10px;
}
.group-data-item{
  margin-bottom: 5px;
}
#canvas{
  width: 600px;
  padding: 200px 20px;
  text-align: center;
  border: 1px solid #333;
  margin: auto;
  margin-top: 10px;
}
</style>
