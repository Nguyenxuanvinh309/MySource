<template>
  <div>
    <h1>{{msg}}</h1>
    <ul class="group-data"><b>Name List: </b>
      <li v-for="item in name" class="group-data-item">+ {{item}}</li>
    </ul>

    <ul class="group-data"><b>Name-Old List: </b>
      <li v-for="item in old" class="group-data-item">+ {{item.name}}-{{item.age}}</li>
    </ul>

    <ul class="group-data"><b>Name-Old Numllet List: </b>
      <li v-for="(item,index) in old" class="group-data-item">{{index}}. {{item.name}}-{{item.age}}</li>
    </ul>

    <ul class="group-data"><b>Name-Old Numllet List by Name: </b>
      <li v-for="(item,index) in old" class="group-data-item">
        <b>Code Number: {{index}}</b>
        <p>Name: {{item.name}}</p>
        <p>Age: {{item.age}}</p>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'Looping',
  data () {
    return {
      msg: 'Looping',
      name: ['Joe','Kai','San','Sun','Lake'],
      old: [
        {name:'Joe', age:'25'},
        {name:'Kai', age:'23'},
        {name:'San', age:'30'},
        {name:'Sun', age:'28'},
        {name:'Lake', age:'40'}
      ],
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
a, span {
  color: #42b983;
}
.color-text, .colortext{
  color: #42b983; 
}
.colortext{
  font-size: 20px;
  font-weight: 600;
}
.group-data{
  margin: auto;
  margin-bottom: 10px;
  text-align: left;
  display: table;
}
.group-data-item{
  margin-bottom: 5px;
  display: list-item;
  list-style-type: inital;
  padding: inital; 
  text-align: center;
}
.group-data-item p{
  margin: 5px;
}
</style>
