<template>
  <div>
    <h1>{{msg}}</h1>
    <div class="group-data">
      <div class="group-data-item">
         <label class="color-text">Name: </label>
         <input type="input" v-bind:value="name">
      </div>

      <div class="group-data-item">
         <label class="color-text">Job: </label>
         <input type="input" v-bind:value="job">
      </div>

      <div class="group-data-item">
         <label class="color-text">Age: </label>
         <input type="input" v-bind:value="age">
      </div>

      <div class="group-data-item">
         <label class="color-text">Website: </label>
         <a v-bind:href="web">{{web}}</a>
      </div>
    </div>
    <a v-bind:href="web">Demo 1</a>
    <a :href="web">Demo 2</a>
    <span v-html="webTag"></span>
  </div>
</template>

<script>
export default {
  name: 'DataBinding',
  data () {
    return {
      msg: 'Data Binding',
      name: 'Kai',
      job: 'DEV',
      age: '23',
      web: 'https://www.google.com.vn',
      webTag: '<a href="https://www.google.com.vn" style="color: #42b983;">Demo 3</a>'
    }
  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
a, span {
  color: #42b983;
}
.color-text{
  color: #42b983; 
}
.group-data{
  margin-bottom: 10px;
}
.group-data-item{
  margin-bottom: 5px;
}
</style>
