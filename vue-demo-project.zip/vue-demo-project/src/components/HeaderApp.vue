<template>
  <div id="header">
    <header>   
      <img src="../assets/logo.png">
      <h1 class="header-title">vue project</h1>
      <ul class="menu-group">
        <li><router-link to="/">Home</router-link></li>
        <li><router-link to="/binding">Data Binding</router-link></li>
        <li><router-link to="/datamethod">Data Method</router-link></li>
        <li><router-link to="/event">Event</router-link></li>
        <li><router-link to="/event-modifier">Event Modifier</router-link></li>
        <li><router-link to="/hello">Hello World</router-link></li>
        <li><router-link to="/keyboard">Keyboard Events</router-link></li>
        <li><router-link to="/two-way-binding">Two-way Data Binding</router-link></li>
        <li><router-link to="/computed">Computed Properties</router-link></li>
        <li><router-link to="/dynamic-css">Dynamic CSS Classes</router-link></li>
        <li><router-link to="/conditional">Conditionals</router-link></li>
        <li><router-link to="/looping">Looping</router-link></li>
      </ul>
    </header>
  </div>
</template>
<script>

export default {
  name: 'header'
}
</script>

<style>
  #header {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
  }
  .menu-group{
    max-width: 1170px;
    margin: auto;
  }
  .menu-group li {
    background: #42b983;
    cursor: pointer;
  }
  .menu-group li.active{
    background: red;
  }
  .menu-group li:hover{
    background: #2c3e50;
    color: #fff;

    transition: 1s;
    -webkit-transition: 1s;
    -moz-transition: 1s;
    -ms-transition: 1s;
    -o-transition: 1s;
  }
  .menu-group li a{
    color: #fff;
    text-decoration: none;
    padding: 10px;
    display: inline-block;
  }
  .header-title{
    text-transform: uppercase;
    font-weight: bold;
  }
  .router-link-exact-active.router-link-active{
    background: #2c3e50;
  }
  .router-link-exact-active.router-link-active:hover{
    background: #42b983;

    transition: 1s;
    -webkit-transition: 1s;
    -moz-transition: 1s;
    -ms-transition: 1s;
    -o-transition: 1s;
  }
</style>
