<template>
  <div>
    <h1>{{msg}}</h1>
    <p v-bind:class="{colortext:false, bcktext: false}">{{name}}</p>
    <p v-bind:class="{colortext:true, bcktext: false}">{{name}}</p>
    <p v-bind:class="{colortext:false, bcktext: true}">{{name}}</p>
    <p v-bind:class="{colortext:true, bcktext: true}">{{name}}</p>
    <p v-bind:class="compClasses">{{name}}</p>
    <button v-on:click="available = !available" type="input">Available</button>
    <button v-on:click="nearby = !nearby" type="input">nearby</button>
  </div>
</template>

<script>
export default {
  name: 'DynamicCSS',
  data () {
    return {
      msg: 'Dynamic CSS Classes',
      name: 'Kai',
      job: 'Dev',
      old: 23,
      available: true,
      nearby: false
    }
  },
  computed:{
    compClasses: function(){
      return{
        nearby: this.nearby,
        available: this.available
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
.information-area{
  font-size: 32px;
  text-transform: uppercase;
}
.information-area li{
  display: list-item;
  font-size: 20px;
}
a, span {
  color: #42b983;
}
.color-text, .colortext{
  color: #42b983; 
}
.colortext{
  font-size: 20px;
  font-weight: 600;
}
.bcktext{
  background: #42b983;
  color: #fff;
  display: table;
  margin: auto;
  padding: 10px 20px;
  margin-top: 5px;
  margin-bottom: 5px;
  cursor: pointer;
}
.bcktext:hover{
  background: #2c3e50;
  color: #fff;

  transition: 1s;
  -webkit-transition: 1s;
  -moz-transition: 1s;
  -ms-transition: 1s;
  -o-transition: 1s;
}
.group-data, .group-button{
  margin-bottom: 10px;
}
.group-data-item{
  margin-bottom: 5px;
}

.available, .nearby{
  background: #42b983;
  color: #fff;
  display: table;
  margin: auto;
  padding: 10px 20px;
  margin-top: 5px;
  margin-bottom: 5px;
  cursor: pointer;
  font-weight: bold;
  font-size: 20px;

  transition: 1s;
  -webkit-transition: 1s;
  -moz-transition: 1s;
  -ms-transition: 1s;
  -o-transition: 1s;
}

.nearby{
  background: red;

  transition: 1s;
  -webkit-transition: 1s;
  -moz-transition: 1s;
  -ms-transition: 1s;
  -o-transition: 1s;
}

</style>
