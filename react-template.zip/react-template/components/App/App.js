import React, { Component } from 'react';
import Header from './Common/Header';
import Footer from './Common/Footer';
import CodeID from './Common/CodeID';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Header></Header>
        <CodeID></CodeID>
        <Footer></Footer>
      </div>
    );
  }
}

export default App;
