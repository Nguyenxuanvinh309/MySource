import React from 'react';
import ReactDOM from 'react-dom';
import './assets/css/index.css';
import App from './components/App/App';
import {Provider} from "react-redux"
import store from "./store"
import registerServiceWorker from './registerServiceWorker';
import Boostrap from 'bootstrap/dist/css/bootstrap.min.css';

ReactDOM.render(<Provider store={store}>
	<App />
</ Provider>, document.getElementById('root'));
registerServiceWorker();
