import React, { Component } from 'react';
import Infor from './Information';

class Body extends Component {
  render() {
    const nameVal = "Kai";

    return (
      <div className="wrap-content">
        <div className="container">
          <div className="row">
            <Infor name={nameVal}/>
            <Infor name='Hip'/>
            <Infor name='Din'/>
          </div>
        </div>
      </div>
    );
  }
}

export default Body;
