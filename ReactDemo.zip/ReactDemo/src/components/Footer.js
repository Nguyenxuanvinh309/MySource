import React, { Component } from 'react';
import logo from '../logo.svg';
import '../App.css';

class Header extends Component {
  render() {
    return (
      <footer className="App-footer">
        <img src={logo} className="App-logo" alt="logo" />
        <h1 className="App-title">Footer</h1>
      </footer>
    );
  }
}

export default Header;
