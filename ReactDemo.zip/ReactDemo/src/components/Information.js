import React, { Component } from 'react';

class Information extends Component {
  constructor(){
    super();
    this.state = {name: 'This is Name'}
  }

  getVal(val){
    return val;
  }

  handleChangeData(e){
    const content = e.target.value;
    this.setState({name: content});
  }

  ChangeNameState(currentVal){
    this.setState({name: currentVal});
  }

  render() {
    const name = this.props.name;

    return (
      <div className="col-md-4">
        <h1>My name is {this.getVal(name)}</h1>
        <p>My state name is <span className="name-info">{this.state.name}</span></p>
        <input type="text"  onChange={this.handleChangeData.bind(this)}/>
      </div>
    );
  }
}

export default Information;
