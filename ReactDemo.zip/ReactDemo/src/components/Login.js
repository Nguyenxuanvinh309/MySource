import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class Login extends Component {
   render() {
      return (
         <div>
            <h2>Login</h2>
            <p>This is login page</p>
         </div>
      );
   }
}
export default Login;
