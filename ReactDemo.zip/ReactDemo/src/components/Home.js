import React, { Component } from 'react';
import Body from './Body';

class Home extends Component {
   render() {
      return (
         <div>
            <h2>Home</h2>
            <Body />
         </div>
      );
   }
}
export default Home;
