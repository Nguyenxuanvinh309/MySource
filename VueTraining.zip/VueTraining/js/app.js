var app = new Vue({
	el: '#app',
	data: {
		message: 'Hello Vue!'
	}
})

var app2 = new Vue({
  el: '#app-2',
  data: {
    message: 'You loaded this page on ' + new Date().toLocaleString()
  }
})

var app3 = new Vue({
  el: '#app-3',
  data: {
    seen: true
  }
})

var app4 = new Vue({
  el: '#app-4',
  data: {
  	message: 'This is list: ',
  	question: 'Default',
  	answer: 'I cannot give you an answer until you ask a question!',
    todos: [
      { text: 'Learn JavaScript' },
      { text: 'Learn Vue' },
      { text: 'Build something awesome' }
    ]
  }, 

  methods:{
  	addTodos: function () {
  		if(this.question === '' || this.question === null){
  			this.question = 'Null';
  		}
  		app4.todos.push({text: this.question});
  	}
  }
})