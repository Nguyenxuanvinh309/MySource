<template>
	<header>
	</header>
</template>

<script>
export default {
	name: 'header',
	data () {
		return {
			msg: 'header'
		}
	}
}
</script>