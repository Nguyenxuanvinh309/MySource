<template>
	<footer>
	</footer>
</template>

<script>
export default {
	name: 'footer',
	data () {
		return {
			msg: 'footer'
		}
	}
}
</script>