<template>
	<div class="wrap-content">
		<h1>{{msg}}</h1>
	</div>
</template>

<script>
export default {
	name: 'body',
	data () {
		return {
			msg: 'Hello'
		}
	}
}
</script>