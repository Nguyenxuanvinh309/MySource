// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import HeaderApp from './components/HeaderApp'
import FooterApp from './components/FooterApp'
import App from './App'
import router from './router'
// import '../static/vendor/jquery/jquery-3.1.1.min.js'
// import '../static/css/main.css'

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue(
	{
	  el: '#app',
	  router,
	  template: '<App/>',
	  components: { App }
	}
)

new Vue(
	{
	  el: '#header',
	  router,
	  template: '<HeaderApp/>',
	  components: { HeaderApp }
	}
)

new Vue(
	{
	  el: '#footer',
	  router,
	  template: '<FooterApp/>',
	  components: { FooterApp }
	}
)
