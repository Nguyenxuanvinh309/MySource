$(document).ready(function(){
	ListItemTextRange(12);
	// LoadItemSidebar(500, 10);
	ActiveSiderItem();
});

/*speedMove: speed load item
  elementNum: Number item in slider menu
*/
// var topPos = null;
// function LoadItemSidebar(speedMove, elementNum){
// 	/*Check element more 8 item show next press*/
// 	if($('.sidebar-comp ul li').length > elementNum){
// 			var hideItem = $('.sidebar-comp ul li').length - elementNum;
// 			// var maxClick = (hideItem * 43) - 1;
// 			var maxScroll = (hideItem * 43) + 2;

// 			/*Show next press*/
// 			$('.sidebar-next-press').addClass('show');
// 			if($('.sidebar-next-press').length > 0){
// 				/*Click next press*/
// 				setTimeout(function(){
// 					$('.sidebar-next-press').click(function(){
// 						topPos = maxScroll;
						
// 						/*Show prev-button*/
// 						$(".sidebar-comp").animate({
// 				        	scrollTop: topPos
// 				    	}, speedMove);

// 				    	$(this).removeClass('show');
// 				    	$('.sidebar-prev-press').addClass('show');
// 					});
// 				},speedMove);
// 			}

// 			if($('.sidebar-prev-press').length > 0){
// 				/*Click next press*/
// 				setTimeout(function(){
// 					$('.sidebar-prev-press').click(function(){
// 						topPos = maxScroll;
						
// 						/*Show prev-button*/
// 						$(".sidebar-comp").animate({
// 				        	scrollTop: 0
// 				    	}, speedMove);

// 				    	$(this).removeClass('show');
// 				    	$('.sidebar-next-press').addClass('show');
// 					});
// 				},speedMove);
// 			}

// 			$('.sidebar-comp').scroll(function(){
// 				var y_start_sliderbar = $('.sidebar-comp').offset().top;
// 				var y_end_sliderbar = $('.sidebar-comp').offset().top + $('.sidebar-comp').height();
					
// 				if(Math.round($(this).scrollTop()) > 0){
// 					if(Math.round($(this).scrollTop()) === maxScroll){
// 						$('.sidebar-next-press').removeClass('show');
// 					}
// 				}else{
// 					$('.sidebar-next-press').addClass('show');
// 				}
// 			});
// 	}
// }

var categorySiderID = 1;

function ActiveSiderItem(){
	$('.list-cataloge-area > ul > li').click(function(){
		if($('.list-cataloge-area > ul > li.active-item')) $('.active-item').removeClass('active-item');
		$(this).addClass('active-item');
		categorySiderID = $(this).index();
		LoadCategory('desktop');
	});
}

/*
Item Text Range of Catogery List
textMax: text max range of Item
*/
function ListItemTextRange(textMax){
	if($('.list-cataloge-area > ul > li').length > 0){
		var itemTotal = $('.list-cataloge-area > ul > li').length;

		for(var i = 1; i < itemTotal; i++){
			var itemList = $('.list-cataloge-area > ul > li:nth-child(' + i + ')');
			var itemListText = itemList.text();

			/*item text > text max range*/
			if(itemList.text().length > textMax){
				itemListText = itemList.text().substring(0, textMax) + '...';
			}
			itemList.text(itemListText);
		}
	}
}