$(document).ready(function(){
	LoadItemSidebar(500, 10);
	ActiveSiderItem();
});

/*speedMove: speed load item
  elementNum: Number item in slider menu
*/
var topPos = null;
function LoadItemSidebar(speedMove, elementNum){
	/*Check element more 8 item show next press*/
	if($('.sidebar-comp ul li').length > elementNum){
			var hideItem = $('.sidebar-comp ul li').length - elementNum;
			// var maxClick = (hideItem * 43) - 1;
			var maxScroll = (hideItem * 43) + 2;

			/*Show next press*/
			$('.sidebar-next-press').addClass('show');
			if($('.sidebar-next-press').length > 0){
				/*Click next press*/
				setTimeout(function(){
					$('.sidebar-next-press').click(function(){
						topPos = maxScroll;
						
						/*Show prev-button*/
						$(".sidebar-comp").animate({
				        	scrollTop: topPos
				    	}, speedMove);

				    	$(this).removeClass('show');
				    	$('.sidebar-prev-press').addClass('show');
					});
				},speedMove);
			}

			if($('.sidebar-prev-press').length > 0){
				/*Click next press*/
				setTimeout(function(){
					$('.sidebar-prev-press').click(function(){
						topPos = maxScroll;
						
						/*Show prev-button*/
						$(".sidebar-comp").animate({
				        	scrollTop: 0
				    	}, speedMove);

				    	$(this).removeClass('show');
				    	$('.sidebar-next-press').addClass('show');
					});
				},speedMove);
			}

			$('.sidebar-comp').scroll(function(){
				var y_start_sliderbar = $('.sidebar-comp').offset().top;
				var y_end_sliderbar = $('.sidebar-comp').offset().top + $('.sidebar-comp').height();
					
				if(Math.round($(this).scrollTop()) > 0){
					if(Math.round($(this).scrollTop()) === maxScroll){
						$('.sidebar-next-press').removeClass('show');
					}
				}else{
					$('.sidebar-next-press').addClass('show');
				}
			});
	}
}

function ActiveSiderItem(){
	$('.sidebar-comp > ul > li').click(function(){
		var itemFirstPosi = $('.sidebar-comp > ul > li:nth-child(1)').offset().top;

		$('.sidebar-comp > ul > li').removeClass('active');
		$('.sidebar-comp > ul > li').css('border-bottom','1px solid #ededed');
		
		$(this).toggleClass('active');
		$(this).prev().css('border','none');
	});
}