$(document).ready(function() {
	// PopOver();
	ActionResult();
	SubmitSaveVote();
	VoteDetailComapny();

	PopUpPress();
	ReadMoreInfoComapany();
	EditDetailCompany();
	AutoHeightTextArea();
	SignOutAccount();

	UploadImage();

	ChangeRadius();
	RangeBarSlider();
	OpenCloseMap();
	SwitchMap();
	GetValueMap();
	// StatisqueChart();
	FieldSearchMobile();
	SelectRegion();
	ChangeLogo();
	// SliderCarousel();
	// SelectThumbnail();
	ShowZoomImage();
	ThumbnailImage();
});

/*----------Map in Homepage (Search Advance)-----------*/
var radiusVal = 15000;
var map;
var markers = [];
var haightAshbury = {lat: 10.8091338, lng: 106.6356394};
var flageOpen = true;
var valueZoom = 9;

function ChangeRadius(){
  $('.radiusRange').change(function(){
    radiusVal = $(this).val();
    radiusVal = parseInt(radiusVal);

    $('#radiusNumber').text(radiusVal/1000 + "km");
    console.log(radiusVal);
    initMap();
  });
}

function RangeBarSlider(){
  $('input[type="range"]').change(function () {
    var val = ($(this).val() - $(this).attr('min')) / ($(this).attr('max') - $(this).attr('min'));

    $(this).css('background-image',
      '-webkit-gradient(linear, left top, right top, '
        + 'color-stop(' + val + ', #0896d5), '
        + 'color-stop(' + val + ', #ced4da)'
        + ')'
    );

    $(this).css('background-image',
      '-moz-gradient(linear, left top, right top, '
        + 'color-stop(' + val + ', #0896d5), '
        + 'color-stop(' + val + ', #ced4da)'
        + ')'
    );

    $(this).css('background-image',
      '-o-gradient(linear, left top, right top, '
        + 'color-stop(' + val + ', #0896d5), '
        + 'color-stop(' + val + ', #ced4da)'
        + ')'
    );

    $(this).css('background-image',
      '-ms-gradient(linear, left top, right top, '
        + 'color-stop(' + val + ', #0896d5), '
        + 'color-stop(' + val + ', #ced4da)'
        + ')'
    );
  });
}

function OpenCloseMap(){
	$('.advance-search').click(function(){
		if(flageOpen == false){
			$('.map-area').css('display','none');
			flageOpen = true;
		}else{
			$('.map-area').css('display','block');
			initMap();
			flageOpen = false;
		}
	});
	$('.btn-search-map-submit').click(function(){
		$('.map-area').css('display','none');
	});
}

function SwitchMap(){
	$('.tab-primary:nth-child(2)').click(function(){
		$('.rejoin-map').css('display','block');
		$('.autour-map').css('display','none');
		$('.tab-primary:nth-child(1)').removeClass('bold');
		$(this).addClass('bold');
	});

	$('.tab-primary:nth-child(1)').click(function(){
		$('.rejoin-map').css('display','none');
		$('.autour-map').css('display','block');
		$('.tab-primary:nth-child(2)').removeClass('bold');
		$(this).addClass('bold');
	});
}

function GetValueMap(){
	$('#fr-1').click(function(){console.log('Id city: 1');});
	$('#fr-2').click(function(){console.log('Id city: 2');});
	$('#fr-3').click(function(){console.log('Id city: 3');});
	$('#fr-4').click(function(){console.log('Id city: 4');});
	$('#fr-5').click(function(){console.log('Id city: 5');});

	$('#fr-6').click(function(){console.log('Id city: 6');});
	$('#fr-7').click(function(){console.log('Id city: 7');});
	$('#fr-8').click(function(){console.log('Id city: 8');});
	$('#fr-9').click(function(){console.log('Id city: 9');});
	$('#fr-10').click(function(){console.log('Id city: 10');});

	$('#fr-11').click(function(){console.log('Id city: 11');});
	$('#fr-12').click(function(){console.log('Id city: 12');});
	$('#fr-13').click(function(){console.log('Id city: 13');});
	$('#fr-14').click(function(){console.log('Id city: 14');});
	$('#fr-15').click(function(){console.log('Id city: 15');});

	$('#fr-16').click(function(){console.log('Id city: 16');});
	$('#fr-17').click(function(){console.log('Id city: 17');});
	$('#fr-18').click(function(){console.log('Id city: 18');});
	$('#fr-19').click(function(){console.log('Id city: 19');});
	$('#fr-20').click(function(){console.log('Id city: 20');});

	$('#fr-21').click(function(){console.log('Id city: 21');});
	$('#fr-22').click(function(){console.log('Id city: 22');});
	$('#fr-23').click(function(){console.log('Id city: 23');});
	$('#fr-24').click(function(){console.log('Id city: 24');});
	$('#fr-25').click(function(){console.log('Id city: 25');});
	$('#fr-26').click(function(){console.log('Id city: 26');});
}

function initMap() {
    map = new google.maps.Map(document.getElementById('map'), {
      zoom: valueZoom,
      center: haightAshbury
    });

    map.addListener('zoom_changed', function() {
      console.log('Zoom: ' + map.getZoom());
      valueZoom = map.getZoom();
    });

    var marker = new google.maps.Marker({
      position: haightAshbury,
      map: map
    });

    var sunCircle = {
      strokeColor: "#c3fc49",
      strokeOpacity: 0.8,
      strokeWeight: 2,
      fillColor: "#c3fc49",
      fillOpacity: 0.35,
      map: map,
      center: haightAshbury,
      radius: radiusVal // in meters
    };
    cityCircle = new google.maps.Circle(sunCircle);
    cityCircle.bindTo('center', marker, 'position');

    // This event listener will call addMarker() when the map is clicked.
    map.addListener('click', function(event) {
      deleteMarkers();
      addMarker(event.latLng);
    });
 }

// Adds a marker to the map and push to the array.
function addMarker(location) {
	var marker = new google.maps.Marker({
	  position: location,
	  map: map
	});

	if(marker != null){
	  haightAshbury = {lat: location.lat(), lng: location.lng()};
	  initMap();
	}
	// markers.push(marker);
	console.log('Latitude: ' + location.lat() + ';' +  ' Longitude: ' + location.lng());
	console.log(radiusVal);
	var sunCircle = {
	  strokeColor: "#c3fc49",
	  strokeOpacity: 0.8,
	  strokeWeight: 2,
	  fillColor: "#c3fc49",
	  fillOpacity: 0.35,
	  map: map,
	  center: {lat: location.lat(), lng: location.lng()},
	  radius: radiusVal // in meters
	};
	cityCircle = new google.maps.Circle(sunCircle);
	cityCircle.bindTo('center', marker, 'position');
}

// Sets the map on all markers in the array.
function setMapOnAll(map) {
	for (var i = 0; i < markers.length; i++) {
	  markers[i].setMap(map);
	}
}

// Removes the markers from the map, but keeps them in the array.
function clearMarkers() {
	setMapOnAll(null);
}

// Deletes all markers in the array by removing references to them.
function deleteMarkers() {
	clearMarkers();
	markers = [];
}

function ActionResult(){
	var itemIdNum = $('.grid-result-left#result-left-itemnum').length;
	for(var i = 1; i <= itemIdNum; i++){
		VoteResult('.grid-result-left:nth-child(' + i + ')');	
	}
}

function VoteResult(resultID){
	/*Action for 1 star*/
    $(resultID + ' .grid--result--left-item .like-star').hover(function(){
        if($('.vote-case').length > 0){
			$(resultID + ' .grid--result--left-item .like-star').removeClass('like-star-yellow');
	        $(resultID + ' .grid--result--left-item .like-star').removeClass('flag-vote');
	        $(this).addClass('flag-vote');
	        $(this).addClass('like-star-yellow');
		}else{
			console.log('Novote');
		}
    });

	$(resultID + ' .grid--result--left-item .like-star').click(function(){
		$(resultID + ' .grid--result--left-item .grid--result--left--item-accept').css('display','block');
	    $(resultID + ' .grid--result--left-item .grid--result--left--item-cancel').css('display','block');
	    $(resultID + ' .grid--result--left-item .grid--result--left--item-numlike').css('display','none');
		
		$(resultID + ' .grid--result--left-item .grid--result--left--item-like').addClass('vote-case');
		if($('.vote-case').length > 0){;
			/*Action for 1 star*/
	        $(resultID + ' .grid--result--left-item .like-star-1').hover(function(){
		        $(resultID + ' .grid--result--left-item .like-star').removeClass('like-star-yellow');
		        $(resultID + ' .grid--result--left-item .like-star').removeClass('flag-vote');
		        $(this).addClass('flag-vote');
		        $(this).addClass('like-star-yellow');
		    });

		    /*Action for 2 star*/
	    	$(resultID + ' .grid--result--left-item .like-star-2').hover(function(){
		        $(resultID + ' .grid--result--left-item .like-star').removeClass('like-star-yellow');
		        $(resultID + ' .grid--result--left-item .like-star-1').addClass('like-star-yellow');
		    	$(resultID + ' .grid--result--left-item .like-star').removeClass('flag-vote');
		    	$(this).addClass('flag-vote');    
		        $(this).addClass('like-star-yellow');
		    });

		    /*Action for 3 star*/
	    	$(resultID + ' .grid--result--left-item .like-star-3').hover(function(){
		        $(resultID + ' .grid--result--left-item .like-star').removeClass('like-star-yellow');
		        $(resultID + ' .grid--result--left-item .like-star-1').addClass('like-star-yellow');
		        $(resultID + ' .grid--result--left-item .like-star-2').addClass('like-star-yellow');
		        $(resultID + ' .grid--result--left-item .like-star').removeClass('flag-vote');
		        $(this).addClass('flag-vote');
		        $(this).addClass('like-star-yellow');
		    });

		    /*Action for 4 star*/
	    	$(resultID + ' .grid--result--left-item .like-star-4').hover(function(){
		        $(resultID + ' .grid--result--left-item .like-star').removeClass('like-star-yellow');
		        $(resultID + ' .grid--result--left-item .like-star-1').addClass('like-star-yellow');
		        $(resultID + ' .grid--result--left-item .like-star-2').addClass('like-star-yellow');
		        $(resultID + ' .grid--result--left-item .like-star-3').addClass('like-star-yellow');
		        $(resultID + ' .grid--result--left-item .like-star').removeClass('flag-vote');
		        $(this).addClass('flag-vote');
		        $(this).addClass('like-star-yellow');
		    });

		    /*Action for 5 star*/
	    	$(resultID + ' .grid--result--left-item .like-star-5').hover(function(){
		        $(resultID + ' .grid--result--left-item .like-star').removeClass('like-star-yellow');
		        $(resultID + ' .grid--result--left-item .like-star-1').addClass('like-star-yellow');
		        $(resultID + ' .grid--result--left-item .like-star-2').addClass('like-star-yellow');
		        $(resultID + ' .grid--result--left-item .like-star-3').addClass('like-star-yellow');
		        $(resultID + ' .grid--result--left-item .like-star-4').addClass('like-star-yellow');
		        $(resultID + ' .grid--result--left-item .like-star').removeClass('flag-vote');
		        $(this).addClass('flag-vote');
		        $(this).addClass('like-star-yellow');
	    	});
		}
	});

    /*Action Cancel Vote*/
    $(resultID + ' .grid--result--left-item .grid--result--left--item-cancel').click(function(){
        $(resultID + ' .grid--result--left-item .grid--result--left--item-accept').css('display','none');
        $(resultID + ' .grid--result--left-item .grid--result--left--item-cancel').css('display','none');
        $(resultID + ' .grid--result--left-item .grid--result--left--item-numlike').css('display','block');
    	$(resultID + ' .grid--result--left-item .grid--result--left--item-like').removeClass('vote-case');
    	
    	$(resultID + ' .grid--result--left-item .like-star-1').off('mouseenter mouseleave');
    	$(resultID + ' .grid--result--left-item .like-star-2').off('mouseenter mouseleave');
    	$(resultID + ' .grid--result--left-item .like-star-3').off('mouseenter mouseleave');
    	$(resultID + ' .grid--result--left-item .like-star-4').off('mouseenter mouseleave');
    	$(resultID + ' .grid--result--left-item .like-star-5').off('mouseenter mouseleave');
    });

    /*Action Accept Vote*/
    $(resultID + ' .grid--result--left-item .grid--result--left--item-accept').click(function(){
        $(resultID + ' .grid--result--left-item .grid--result--left--item-accept').css('display','none');
        $(resultID + ' .grid--result--left-item .grid--result--left--item-cancel').css('display','none');
        $(resultID + ' .grid--result--left-item .grid--result--left--item-numlike').css('display','block');
    	$(resultID + ' .grid--result--left-item .grid--result--left--item-like').removeClass('vote-case');
    	
    	$(resultID + ' .grid--result--left-item .like-star-1').off('mouseenter mouseleave');
    	$(resultID + ' .grid--result--left-item .like-star-2').off('mouseenter mouseleave');
    	$(resultID + ' .grid--result--left-item .like-star-3').off('mouseenter mouseleave');
    	$(resultID + ' .grid--result--left-item .like-star-4').off('mouseenter mouseleave');
    	$(resultID + ' .grid--result--left-item .like-star-5').off('mouseenter mouseleave');
    });
}

function VoteDetailComapny(){
	if($('.grid-detailcompay-votearea .like-star').length > 0){
		$('.grid-detailcompay-votearea .like-star-1').hover(function(){
			$('.grid-detailcompay-votearea .like-star').removeClass('like-star-yellow');
			$(this).addClass('like-star-yellow');
		});

		$('.grid-detailcompay-votearea .like-star-2').hover(function(){
			$('.grid-detailcompay-votearea .like-star').removeClass('like-star-yellow');
			$('.grid-detailcompay-votearea .like-star-1').addClass('like-star-yellow');
			$(this).addClass('like-star-yellow');
		});

		$('.grid-detailcompay-votearea .like-star-3').hover(function(){
			$('.grid-detailcompay-votearea .like-star').removeClass('like-star-yellow');
			$('.grid-detailcompay-votearea .like-star-1').addClass('like-star-yellow');
			$('.grid-detailcompay-votearea .like-star-2').addClass('like-star-yellow');
			$(this).addClass('like-star-yellow');
		});

		$('.grid-detailcompay-votearea .like-star-4').hover(function(){
			$('.grid-detailcompay-votearea .like-star').removeClass('like-star-yellow');
			$('.grid-detailcompay-votearea .like-star-1').addClass('like-star-yellow');
			$('.grid-detailcompay-votearea .like-star-2').addClass('like-star-yellow');
			$('.grid-detailcompay-votearea .like-star-3').addClass('like-star-yellow');
			$(this).addClass('like-star-yellow');
		});

		$('.grid-detailcompay-votearea .like-star-5').hover(function(){
			$('.grid-detailcompay-votearea .like-star').removeClass('like-star-yellow');
			$('.grid-detailcompay-votearea .like-star-1').addClass('like-star-yellow');
			$('.grid-detailcompay-votearea .like-star-2').addClass('like-star-yellow');
			$('.grid-detailcompay-votearea .like-star-3').addClass('like-star-yellow');
			$('.grid-detailcompay-votearea .like-star-4').addClass('like-star-yellow');
			$(this).addClass('like-star-yellow');
		});
	}
}

function SubmitSaveVote(){
	$('button.btn.btn-default.btn-save-submit').click(function(){
		if($(this).hasClass('save')){
			$(this).removeClass('save');
		}else{
			$(this).addClass('save');
		}
	});
}

function PopOver(){
	if($('[data-toggle="popover"]').length > 0){
		$('[data-toggle="popover"]').popover(); 
	}
}

function ReadMoreInfoComapany(){
	/*max string of description is '200'*/
	var maxLengthDesktop = $('.grid-detailcompay-description.desktop').text().length - 10;
	var maxLenghthMobile = $('.grid-detailcompay-description.mobile').text().length - 10;

	if(maxLengthDesktop <= 200 || maxLenghthMobile <= 200){
		$('.grid-detailcompay-readmore').css('display','none');
		$('.grid-detailcompay-resetdesp').css('display','none');
	}else{
		$('.grid-detailcompay-readmore').click(function(){
			$('.grid-detailcompay-description').css('height','auto');
			$(this).css('display','none');
			$('.grid-detailcompay-resetdesp').css('display','block');
			$('.grid-detailcompay-resetdesp').css('margin-left','0');
		});

		$('.grid-detailcompay-resetdesp').click(function(){
			$('.grid-detailcompay-description').css('height','70px');
			$(this).css('display','none');
			$('.grid-detailcompay-readmore').css('display','block');
		});
	}
}

var activeFlag = true;
var activeEquiqe= true;
var activeCataLeft = true;
var activeCataRight = true;
var activeMain = true;

function EditDetailCompany(){
	$('.btn-modifire-submit').click(function(){
		ActionModifire();
		$(this).css('display','none');
	});

	$('.btn-terminer-submit').click(function(){
		ActionTerminer();	
		$(this).css('display','none');
	});

	// $('.btn-valider-submit').click(function(){
	// 	ActionTerminer();
	// });

	/*Edit main block*/
	$('.grid-detailcompay-editarea.main-part').click(function(){
		if(activeMain == false){
			activeMain = true;
			$('.grid-detailcompay-editimage-area.main-part').css('display','none');
			$('.grid-detailcompay-delimage-area.main-part').css('display','none');
			$('.grid--detailcompay--info-name').attr('disabled', 'disabled');
			$('.grid--detailcompay--info-name').css('border','none');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.position .main-part').attr('disabled', 'disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.position .main-part').css('border','none');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.mail .main-part').attr('disabled', 'disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.mail .main-part').css('border','none');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.phone .main-part').attr('disabled', 'disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.phone .main-part').css('border','none');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.twinter .main-part').attr('disabled', 'disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.twinter .main-part').css('border','none');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.facebook .main-part').attr('disabled', 'disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.facebook .main-part').css('border','none');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.in .main-part').attr('disabled', 'disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.in .main-part').css('border','none');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.net .main-part').attr('disabled', 'disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.net .main-part').css('border','none');
			$('.grid-detailcompay-social .grid--detailcompay--social-area > p .main-part').attr('disabled', 'disabled');
			$('.grid-detailcompay-social .grid--detailcompay--social-area > p .main-part').css('border','none');
			$('.detailcompay-description-edit').css('display','none');
			$('.grid-detailcompay-description.desktop').css('display','block');
			$('.grid-detailcompay-readmore').css('display','block');
			$('.main-part.street-dropicon').addClass('street-back');
			$('li.social-edit').css('display','none');
			$('.grid--detailcompay--social-area.social-area-edit').css('display','block');
			$('.grid-detailcompay-editarea.main-part .group-edit-area').css('display','none');
			$('.grid-detailcompay-editarea.main-part .grid-detailcompay-title').css('margin-top','20px');
			$('.grid-detailcompay-editarea.main-part .grid-detailcompay-edit').css('display','block');
			$('.grid-detailcompay-editarea.main-part .grid-detailcompay-del').css('display','block');
		}else{
			$('.grid-detailcompay-editimage-area.main-part').css('display','block');
			$('.grid-detailcompay-delimage-area.main-part').css('display','block');
			$('.grid--detailcompay--info-name').removeAttr('disabled');
			$('.grid--detailcompay--info-name').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.position .main-part').removeAttr('disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.position .main-part').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.mail .main-part').removeAttr('disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.mail .main-part').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.phone .main-part').removeAttr('disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.phone .main-part').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.facebook .main-part').removeAttr('disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.facebook .main-part').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.net .main-part').removeAttr('disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.net .main-part').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.in .main-part').removeAttr('disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.in .main-part').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.twinter .main-part').removeAttr('disabled');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.twinter .main-part').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-social .grid--detailcompay--social-area > p .main-part').removeAttr('disabled');
			$('.grid-detailcompay-social .grid--detailcompay--social-area > p .main-part').css('border','1px solid #e5e5e5');
			$('.detailcompay-description-edit').css('display','block');
			$('.grid-detailcompay-description.desktop').css('display','none');
			$('.grid-detailcompay-readmore').css('display','none');
			$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.position select.main-part').removeAttr('disabled');
			$('.main-part.street-dropicon.street-back').removeClass('street-back');
			$('li.social-edit').css('display','inline-flex');
			$('.grid--detailcompay--social-area.social-area-edit').css('display','none');
			$('.grid-detailcompay-editarea.main-part .group-edit-area').css('display','inline-block');
			$('.grid-detailcompay-editarea.main-part .grid-detailcompay-title').css('margin-top','50px');
			$('.grid-detailcompay-editarea.main-part .grid-detailcompay-edit').css('display','none');
			$('.grid-detailcompay-editarea.main-part .grid-detailcompay-del').css('display','none');
			activeMain = false;
		}
	});


	/*Edit active block*/
	$('.grid-detailcompay-editarea.active-part').click(function(){
		if(activeFlag == false){
			activeFlag = true;
			$('.grid-detailcompay-editimage-area.active-part').css('display','none');
			$('.grid-detailcompay-delimage-area.active-part').css('display','none');
			$('.grid-detailcompay-title.active').attr('disabled', 'disabled');
			$('.grid-detailcompay-title.active').css('border','none');
			$('.grid-detailcompany-description.active-part').attr('disabled', 'disabled');
			$('.grid-detailcompany-description.active-part').css('border','none');
			$('.grid-detailcompay-activetitle').attr('disabled', 'disabled');
			$('.grid-detailcompay-activedes').attr('disabled', 'disabled');
			$('.grid-detailcompay-activetitle').css('border','none');
			$('.grid-detailcompay-activedes').css('border','none');
			$('.item-slider.item-slider-newbig').css('display','none');

			$('.grid-detailcompay-editarea.active-part .group-edit-area').css('display','none');
			$('textarea.grid-detailcompay-title.active').css('margin-top','20px');
			$('.grid-detailcompay-editarea.active-part .grid-detailcompay-edit').css('display','block');
			$('.grid-detailcompay-editarea.active-part .grid-detailcompay-del').css('display','block');
		}else{
			$('.grid-detailcompay-editimage-area.active-part').css('display','block');
			$('.grid-detailcompay-delimage-area.active-part').css('display','block');
			$('.grid-detailcompay-title.active').removeAttr('disabled');
			$('.grid-detailcompay-title.active').css('border','1px solid #e5e5e5');
			$('.grid-detailcompany-description.active-part').removeAttr('disabled');
			$('.grid-detailcompany-description.active-part').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-activetitle').removeAttr('disabled');
			$('.grid-detailcompay-activedes').removeAttr('disabled');
			$('.grid-detailcompay-activetitle').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-activedes').css('border','1px solid #e5e5e5');
			$('.item-slider.item-slider-newbig').css('display','block');
			$('.grid-detailcompay-editarea.active-part .group-edit-area').css('display','inline-block');
			$('textarea.grid-detailcompay-title.active').css('margin-top','50px');
			$('.grid-detailcompay-editarea.active-part .grid-detailcompay-edit').css('display','none');
			$('.grid-detailcompay-editarea.active-part .grid-detailcompay-del').css('display','none');
			activeFlag = false;
		}
	});

	/*Edit equique block*/
	$('.grid-detailcompay-editarea.equiqe-part').click(function(){
		if(activeEquiqe == false){
			activeEquiqe = true;
			$('.grid-detailcompay-editimage-area.equiqe').css('display','none');
			$('.grid-detailcompay-delimage-area.equiqe').css('display','none');
			$('.grid-detailcompay-equipename').attr('disabled', 'disabled');
			$('.grid-detailcompay-equipejob').attr('disabled', 'disabled');
			$('.grid-detailcompay-title.equipe').attr('disabled', 'disabled');
			$('.grid-detailcompay-equipename').css('border', 'none');
			$('.grid-detailcompay-equipejob').css('border', 'none');
			$('.grid-detailcompay-title.equipe').css('border','none');
			$('.grid-detailcompany-description.equiqe-part').attr('disabled', 'disabled');
			$('.grid-detailcompany-description.equiqe-part').css('border','none');
			$('.item-slider.item-slider-newbig.equipe').css('display','none');
			$('.grid-detailcompay-editarea.equiqe-part .group-edit-area').css('display','none');
			$('textarea.grid-detailcompay-title.equiqe').css('margin-top','20px');
			$('.grid-detailcompay-editarea.equiqe-part .grid-detailcompay-edit').css('display','block');
			$('.grid-detailcompay-editarea.equiqe-part .grid-detailcompay-del').css('display','block');
		}else{
			$('.grid-detailcompay-editimage-area.equiqe').css('display','block');
			$('.grid-detailcompay-delimage-area.equiqe').css('display','block');
			$('.grid-detailcompay-equipename').removeAttr('disabled');
			$('.grid-detailcompay-equipejob').removeAttr('disabled');
			$('.grid-detailcompay-title.equipe').removeAttr('disabled');
			$('.grid-detailcompay-equipename').css('border', '1px solid #e5e5e5');
			$('.grid-detailcompay-equipejob').css('border', '1px solid #e5e5e5');
			$('.grid-detailcompay-title.equipe').css('border','1px solid #e5e5e5');
			$('.grid-detailcompany-description.equiqe-part').removeAttr('disabled');
			$('.grid-detailcompany-description.equiqe-part').css('border','1px solid #e5e5e5');
			$('.item-slider.item-slider-newbig.equipe').css('display','block');
			$('.grid-detailcompay-editarea.equiqe-part .group-edit-area').css('display','inline-block');
			$('textarea.grid-detailcompay-title.equipe').css('margin-top','50px');
			$('.grid-detailcompay-editarea.equiqe-part .grid-detailcompay-edit').css('display','none');
			$('.grid-detailcompay-editarea.equiqe-part .grid-detailcompay-del').css('display','none');
			activeEquiqe = false;
		}
	});

	/*Edit catalogue block*/
		/*Left Block*/
	$('.row .col-md-6:nth-child(1) .grid-detailcompay-right.grid-detailcompay-desktop.mobile .grid-detailcompay-editarea.catalogue').click(function(){
		var catalogue_left = '.row .col-md-6:nth-child(1) .grid-detailcompay-right.grid-detailcompay-desktop.mobile .grid-detailcompay-editarea.catalogue';
		if(activeCataLeft == false){
			$('.grid-detailcompay-editimage-area.catalogue.catalogue-left').css('display','none');
			$('.grid-detailcompay-delimage-area.catalogue.catalogue-left').css('display','none');
			$('.grid-detailcompay-title.catalogue-left').attr('disabled', 'disabled');
			$('.grid-detailcompany-description.catalogue-left').attr('disabled', 'disabled');
			$('.grid-detailcompany-description.catalogue-left').css('border', 'none');
			$('.grid-detailcompay-title.catalogue-left').css('border', 'none');
			$('.grid-detailcompay-cataloguetitle.catalogue-left').attr('disabled', 'disabled');
			$('.grid-detailcompay-cataloguetitle.catalogue-left').css('border','none');
			$('.grid-detailcompay-cataloguedes.catalogue-left').attr('disabled', 'disabled');
			$('.grid-detailcompay-cataloguedes.catalogue-left').css('border','none');
			$('.slider.slider-catalogue .item-slider-new.left').css('display','none');
			$(catalogue_left + ' .group-edit-area').css('display','none');
			$('textarea.grid-detailcompay-title.catalogue-left').css('margin-top','20px');
			$(catalogue_left + ' .grid-detailcompay-edit').css('display','block');
			$(catalogue_left + ' .grid-detailcompay-del').css('display','block');
			activeCataLeft = true;
		}else{
			$('.grid-detailcompay-editimage-area.catalogue.catalogue-left').css('display','block');
			$('.grid-detailcompay-delimage-area.catalogue.catalogue-left').css('display','block');
			$('.grid-detailcompay-title.catalogue-left').removeAttr('disabled');
			$('.grid-detailcompany-description.catalogue-left').removeAttr('disabled');
			$('.grid-detailcompay-title.catalogue-left').css('border', '1px solid #e5e5e5');
			$('.grid-detailcompany-description.catalogue-left').css('border', '1px solid #e5e5e5');
			$('.grid-detailcompay-cataloguetitle.catalogue-left').removeAttr('disabled');
			$('.grid-detailcompay-cataloguetitle.catalogue-left').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-cataloguedes.catalogue-left').removeAttr('disabled');
			$('.grid-detailcompay-cataloguedes.catalogue-left').css('border','1px solid #e5e5e5');
			$('.slider.slider-catalogue .item-slider-new.left').css('display','block');
			$(catalogue_left + ' .group-edit-area').css('display','inline-block');
			$('textarea.grid-detailcompay-title.catalogue-left').css('margin-top','50px');
			$(catalogue_left + ' .grid-detailcompay-edit').css('display','none');
			$(catalogue_left + ' .grid-detailcompay-del').css('display','none');
			activeCataLeft = false;
		}
	});
		/*Right Block*/
	$('.row .col-md-6:nth-child(2) .grid-detailcompay-right.grid-detailcompay-desktop.mobile .grid-detailcompay-editarea.catalogue').click(function(){
		var catalogue_right = '.row .col-md-6:nth-child(2) .grid-detailcompay-right.grid-detailcompay-desktop.mobile .grid-detailcompay-editarea.catalogue';
		if(activeCataRight == false){
			$('.grid-detailcompay-editimage-area.catalogue.catalogue-right').css('display','none');
			$('.grid-detailcompay-delimage-area.catalogue.catalogue-right').css('display','none');
			$('.grid-detailcompay-title.catalogue-right').attr('disabled', 'disabled');
			$('.grid-detailcompany-description.catalogue-right').attr('disabled', 'disabled');
			$('.grid-detailcompany-description.catalogue-right').css('border', 'none');
			$('.grid-detailcompay-title.catalogue-right').css('border', 'none');
			$('.grid-detailcompay-cataloguetitle.catalogue-right').attr('disabled', 'disabled');
			$('.grid-detailcompay-cataloguetitle.catalogue-right').css('border','none');
			$('.grid-detailcompay-cataloguedes.catalogue-right').attr('disabled', 'disabled');
			$('.grid-detailcompay-cataloguedes.catalogue-right').css('border','none');
			$('.slider.slider-catalogue .item-slider-new.right').css('display','none');
			$(catalogue_right + ' .group-edit-area').css('display','none');
			$('textarea.grid-detailcompay-title.catalogue-right').css('margin-top','20px');
			$(catalogue_right + ' .grid-detailcompay-edit').css('display','block');
			$(catalogue_right + ' .grid-detailcompay-del').css('display','block');
			activeCataRight = true;
		}else{
			$('.grid-detailcompay-editimage-area.catalogue.catalogue-right').css('display','block');
			$('.grid-detailcompay-delimage-area.catalogue.catalogue-right').css('display','block');
			$('.grid-detailcompay-title.catalogue-right').removeAttr('disabled');
			$('.grid-detailcompany-description.catalogue-right').removeAttr('disabled');
			$('.grid-detailcompay-title.catalogue-right').css('border', '1px solid #e5e5e5');
			$('.grid-detailcompany-description.catalogue-right').css('border', '1px solid #e5e5e5');
			$('.grid-detailcompay-cataloguetitle.catalogue-right').removeAttr('disabled');
			$('.grid-detailcompay-cataloguetitle.catalogue-right').css('border','1px solid #e5e5e5');
			$('.grid-detailcompay-cataloguedes.catalogue-right').removeAttr('disabled');
			$('.grid-detailcompay-cataloguedes.catalogue-right').css('border','1px solid #e5e5e5');
			$('.slider.slider-catalogue .item-slider-new.right').css('display','block');
			$('.grid-detailcompay-editimage-area.catalogue.catalogue-new').css('display','block');
			$(catalogue_right + ' .group-edit-area').css('display','inline-block');
			$('textarea.grid-detailcompay-title.catalogue-right').css('margin-top','50px');
			$(catalogue_right + ' .grid-detailcompay-edit').css('display','none');
			$(catalogue_right + ' .grid-detailcompay-del').css('display','none');
			activeCataRight = false;
		}
	});
}

function ActionModifire(){
	$('.grid-detailcompay-editarea').css('display','block');
	$('.grid-detailcompay-editinfoarea').css('display','block');
	$('.btn-terminer-submit').css('display','block');
	$('.grid-detailcompay-savesubmit.modifier').css('display','inherit');
	$('.grid-detailcompay-savesubmit.modifier').css('margin-left','-15px');
	$('.grid-detailcompay-savesubmit.modifier').css('margin-right','-15px');
	$('.modifier-catalogue').css('display','block');
}

function ActionTerminer(){
	$('.grid-detailcompay-editarea').css('display','none');
	$('.grid-detailcompay-editinfoarea').css('display','none');
	$('.btn-modifire-submit').css('display','block');
	$('.grid-detailcompay-savesubmit.modifier').css('display','table');
	$('.grid-detailcompay-savesubmit.modifier').css('margin','auto');
	$('.modifier-catalogue').css('display','none');
	$('.grid-detailcompay-delimage-area').css('display','none');
	$('.grid-detailcompay-delimage-area.equiqe').css('display','none');
	$('.grid-detailcompay-editimage-area').css('display','none');
	$('.grid-detailcompay-editimage-area.equiqe').css('display','none');

	$('.grid-detailcompay-equipename').attr('disabled', 'disabled');
	$('.grid-detailcompay-equipejob').attr('disabled', 'disabled');
	$('.grid-detailcompay-equipename').css('border', 'none');
	$('.grid-detailcompay-equipejob').css('border', 'none');
	$('.grid-detailcompay-title.equipe').attr('disabled', 'disabled');
	$('.grid-detailcompay-title.equipe').css('border','none');
	$('.grid-detailcompany-description.equiqe-part').attr('disabled', 'disabled');
	$('.grid-detailcompany-description.equiqe-part').css('border','none');

	$('.grid-detailcompay-title.catalogue-left').css('border', 'none');
	$('.grid-detailcompany-description.catalogue-left').css('border', 'none');
	$('.grid-detailcompay-title.catalogue-left').attr('disabled', 'disabled');
	$('.grid-detailcompany-description.catalogue-left').attr('disabled', 'disabled');
	$('.grid-detailcompay-cataloguetitle.catalogue-left').attr('disabled', 'disabled');
	$('.grid-detailcompay-cataloguedes.catalogue-left').attr('disabled', 'disabled');
	$('.grid-detailcompay-cataloguetitle.catalogue-left').css('border','none');
	$('.grid-detailcompay-cataloguedes.catalogue-left').css('border','none');
	$('.slider.slider-catalogue .item-slider-new.left').css('display','none');
	$('.slider.slider-catalogue .item-slider-new.right').css('display','none');

	$('.grid-detailcompay-title.catalogue-right').attr('disabled', 'disabled');
	$('.grid-detailcompany-description.catalogue-right').attr('disabled', 'disabled');
	$('.grid-detailcompany-description.catalogue-right').css('border', 'none');
	$('.grid-detailcompay-title.catalogue-right').css('border', 'none');
	$('.grid-detailcompay-cataloguetitle.catalogue-right').attr('disabled', 'disabled');
	$('.grid-detailcompay-cataloguetitle.catalogue-right').css('border','none');
	$('.grid-detailcompay-cataloguedes.catalogue-right').attr('disabled', 'disabled');
	$('.grid-detailcompay-cataloguedes.catalogue-right').css('border','none');
	$('.group-edit-area').css('display','none');
	$('.grid-detailcompay-title').css('margin-top','20px');
	$('.grid-detailcompay-edit').css('display','block');
	$('.grid-detailcompay-del').css('display','block');

	$('.grid-detailcompay-title.active').attr('disabled', 'disabled');
	$('.grid-detailcompay-title.active').css('border','none');
	$('.grid-detailcompany-description.active-part').attr('disabled', 'disabled');
	$('.grid-detailcompany-description.active-part').css('border','none');
	$('.grid-detailcompay-activetitle').attr('disabled', 'disabled');
	$('.grid-detailcompay-activedes').attr('disabled', 'disabled');
	$('.grid-detailcompay-activetitle').css('border','none');
	$('.grid-detailcompay-activedes').css('border','none');
	$('.item-slider.item-slider-newbig').css('display','none');

	$('.grid--detailcompay--info-name').attr('disabled', 'disabled');
	$('.grid--detailcompay--info-name').css('border','none');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.position .main-part').attr('disabled', 'disabled');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.position .main-part').css('border','none');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.mail .main-part').attr('disabled', 'disabled');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.mail .main-part').css('border','none');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.phone .main-part').attr('disabled', 'disabled');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.phone .main-part').css('border','none');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.twinter .main-part').attr('disabled', 'disabled');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.twinter .main-part').css('border','none');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.facebook .main-part').attr('disabled', 'disabled');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.facebook .main-part').css('border','none');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.in .main-part').attr('disabled', 'disabled');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.in .main-part').css('border','none');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.net .main-part').attr('disabled', 'disabled');
	$('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.net .main-part').css('border','none');
	$('.grid-detailcompay-social .grid--detailcompay--social-area > p .main-part').attr('disabled', 'disabled');
	$('.grid-detailcompay-social .grid--detailcompay--social-area > p .main-part').css('border','none');
	$('.detailcompay-description-edit').css('display','none');
	$('.grid-detailcompay-description.desktop').css('display','block');
	$('.grid-detailcompay-readmore').css('display','block');
	$('.main-part.street-dropicon').addClass('street-back');
	$('li.social-edit').css('display','none');
	$('.grid--detailcompay--social-area.social-area-edit').css('display','block');

	$('.grid-detailcompay-editarea.main-part .group-edit-area').css('display','none');
	$('.grid-detailcompay-editarea.main-part .grid-detailcompay-title').css('margin-top','20px');
	$('.grid-detailcompay-editarea.main-part .grid-detailcompay-edit').css('display','block');
	$('.grid-detailcompay-editarea.main-part .grid-detailcompay-del').css('display','block');
}

function AutoHeightTextArea(){
	AutoSizeTextarea($(".grid-detailcompany-description.active-part"));
	AutoSizeTextarea($('.grid-detailcompany-description.active-part'));
    AutoSizeTextarea($('.grid-detailcompay-right .grid-detailcompay-activetitle'));

	auto_grow($('.grid-detailcompany-description.catalogue-left'));
	auto_grow($('.grid-detailcompay-cataloguetitle.catalogue-left'));
	auto_grow($('.grid-detailcompay-cataloguedes.catalogue-left'));
	auto_grow($('.grid-detailcompany-description.catalogue-right'));
	auto_grow($('.grid-detailcompay-cataloguetitle.catalogue-right'));
	auto_grow($('.grid-detailcompay-cataloguedes.catalogue-right'));
	auto_grow($('.grid--detailcompay--info-name'));
	auto_grow($('.grid-detailcompay-title.active'));
	auto_grow($('.grid-detailcompay-title.equipe'));
	auto_grow($('.grid-detailcompay-title.catalogue-right'));
	auto_grow($('.grid-detailcompay-title.catalogue-left'));
	auto_grow($('.grid-detailcompay-activetitle'));
	auto_grow($('.grid-detailcompay-activedes'));
	auto_grow($('.grid-detailcompay-equipename'));
	auto_grow($('.grid-detailcompay-equipejob'));
	auto_grow($('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.position .main-part'));
	auto_grow($('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.mail .main-part'));
	auto_grow($('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.phone .main-part'));
	auto_grow($('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.net.social-edit .main-part'));
	auto_grow($('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.facebook.social-edit .main-part'));
	auto_grow($('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.twinter.social-edit .main-part'));
	auto_grow($('.grid-detailcompay-info .grid--detailcompay--info-address ul > li.in.social-edit .main-part'));
	auto_grow($('.grid-detailcompany-description.active-part'));
	auto_grow($('.grid-detailcompany-description.equiqe-part'));
}
function auto_grow($element) {
	var $element = 
    $($element).keyup(function(){
    	var heightTextarea = 5;
    	heightTextarea = $(this).prop('scrollHeight') + 'px';
    	console.log(heightTextarea);
    	$(this).css('height', heightTextarea);
    });
}

var signInFlag = true;
function SignOutAccount(){
	$('.sign-out-account').click(function(){
		if($('.dropdown.open-signin').hasClass('open')){
			$(this).removeClass('open');
			alert('Sign Out Account');
			signInFlag = false;
		}
		if($('.header-group-icon').hasClass('signin')){
			$('.header-group-icon').removeClass('signin');
		}
		if($('.header-item.dropdown-toggle.dropdown-toggle-signin').hasClass('signin')){
			$('.header-item.dropdown-toggle.dropdown-toggle-signin').removeClass('signin');
		}
		if($('.header--icon-account').hasClass('signin')){
			$('.header--icon-account').removeClass('signin');
		}
		$('.header-item.dropdown-toggle.dropdown-toggle-signin:nth-child(2)').text('Connexion Inscription');
		$('.navbar-default .navbar-collapse').css('min-height','inherit');
	});

	$('.dropdown.open-signin').click(function(){
		if(signInFlag == false){
			$(this).removeClass('open');
			$('.dropdown-toggle-signin').attr('data-toggle','');
		}
	});
}

function UploadImage(){
	/*Status of Upload Image*/
	$('.inputfile-area').click(function(){
		$('#file').change(function(){
			$('.profile-add-image-btn').text('Uploaded');
		});
	});

	/*Status of Remove Image*/
	$('.btn-remove-img').click(function(){
		$('.profile-add-image-btn').text('Cliquer pour télécharger/ modifier');
		$('#file').val() = null;
	})
}

function StatisqueChart(){
	google.charts.load('current', {'packages':['bar']});
	google.charts.setOnLoadCallback(drawChart);

	function drawChart() {
		var data = google.visualization.arrayToDataTable([
			['Month', 'Visite sur la fiche', 'Clique sur telephone', 'Clique sur email'],
			['1', 1000, 400, 200],
			['2', 1170, 460, 250],
			['3', 660, 1120, 300],
			['4', 1030, 540, 350],
			['5', 1030, 540, 350],
			['6', 1030, 540, 350]
			]);

		var options = {
			chart: {
				title: 'Performance Yatoo',
				subtitle: 'Visite sur la fiche, Clique sur telephone, and Clique sur email: 01/2017 - 12/2017',
			},
			vAxis: {format: 'decimal'},
			height: 410,
			colors: ['#1b9e77', '#d95f02', '#7570b3']
		};

		var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

		chart.draw(data, google.charts.Bar.convertOptions(options));
	}
}

function PopUpPress(){
	/*valCase: Case message content*/
	/*modalMess: Message of Modal*/
	/*btn: button click to show modal message*/

	PopUpMessage(2, $('.message-catalog'), $('.btn-saveedit-submit'));
	PopUpMessage(1, $('.message-catalog'), $('.btn-canceledit-submit'));
}

function PopUpMessage(valCase, $modalMess, $btn){
	var messageModal = $modalMess;
	var acceptbtn = $btn;

	acceptbtn.click(function(e){
		switch(valCase){
			case 1:{
				/* Delete Message Modal*/
				messageModal.text('Voulez-vous vraiment supprimer ce catalogue?');
			};break;
			case 2:{
				/* Pay to add more*/
				messageModal.text('Vous avez ajouté 1 élements.Veuillez payer pour pouvoir ajouter plus.');
			};break;
			case 3:{
				/* Maxium number element*/
				messageModal.text('You have added the maximum number of possible elements in this version');
			};break;
			deault: break;
		}
	});
}
                                       
function FieldSearchMobile(){
	var regionMobile = $('.select-search-area:nth-child(2)');
	var comboVar = $('#localisation');    
	var lableMobile = $('.select-search-area:nth-child(2) div .search-lable');
	var selectMobile = $('.select-search-area:nth-child(2) div select');
	var limitMobile = $('.limit');

	regionMobile.css('display','none');

	comboVar.on("change",function(){
		if(comboVar.val() === 'loca1'){
			regionMobile.css('display','block');
			selectMobile.css('display','none');
			lableMobile.css('display','block');
			limitMobile.css('display','block');
			lableMobile.text('Périmètre');
		}else{
			selectMobile.css('display','block');
			lableMobile.css('display','block');
			regionMobile.css('display','block');
			limitMobile.css('display','none');
			lableMobile.text('Région');
		}
	});
}

function SelectRegion(){
	for(i = 0; i <= 26; i++){
		$('path#fr-' + i).click(function(){
			$('path.emptypath').css('fill','#e05b4c');
			$('path.emptypath').css('stroke','#f08073');
			$('.trackable path:hover').css('fill','#ff887a');
			$('#bretagne:hover').css('fill','#ff887a');
			$('a:hover > path.emptypath').css('fill','#ff887a');
			$('g.emptypath:hover > path').css('fill','#ff887a');
			$('g#fr-22 path').css('fill','#e05b4c');
			$('g#fr-22 path').css('stroke','#f08073');

		 	$(this).css('fill','#ff887a');
		 	$(this).css('stroke','#ff887a');
		});
		$('g#fr-22 path').click(function(){
			$('path.emptypath').css('fill','#e05b4c');
			$('path.emptypath').css('stroke','#f08073');
			$('.trackable path:hover').css('fill','#ff887a');
			$('#bretagne:hover').css('fill','#ff887a');
			$('a:hover > path.emptypath').css('fill','#ff887a');
			$('g.emptypath:hover > path').css('fill','#ff887a');

			$(this).css('fill','#ff887a');
		 	$(this).css('stroke','#ff887a');
		});	
	}	
}

function ChangeLogo(){
	if($('.logo').length > 0){
		if($( window ).width() <= 767){
			$('.logo-mb').css('display','block');
			$('.logo').css('display','none');
		}
	}
}

function AutoSizeTextarea(nameElement){
	var nameTextarea = nameElement;
	if(nameTextarea.length > 0){
		nameTextarea.height( nameTextarea[0].scrollHeight);
	}
}

function ShowZoomImage(){
	var currentURL = $(location).attr('href');
	$('.image-zoom-item').click(function(){
		var currentID = $(this).attr('data-hash');
		var currentImgURL = currentURL+currentID;
		var indexImageID = currentImgURL.indexOf('#');
		var currentURLShow = null;
		
		if(currentImgURL.indexOf('#')!=-1){
			currentURLShow = currentImgURL.slice(0,indexImageID);
			currentURLShow = currentURLShow + '#' + currentID;
			$(location).attr('href', currentURLShow);
		}else{
			currentURLShow = currentURL + '#' + currentID;
			$(location).attr('href', currentURLShow);
		}
	});
}

var flagThumbHover = true;
function ThumbnailImage(){
	/*Hover item in thumbnail image: show arrow of thumbnail*/
	if($('.owl-carousel.thumbnail').length > 0){
		$('.owl-carousel.thumbnail').children().children()
			.mouseover(function(){
				$('#zoomImg .thumbnail .owl-nav').css('display','block');
			})
			.mouseout(function(){
				$('#zoomImg .thumbnail .owl-nav').css('display','none');
				$('#zoomImg .thumbnail .owl-nav .owl-next')
					.mouseover(function(){
						$('#zoomImg .thumbnail .owl-nav').css('display','block');
						flagThumbHover = false;
					})
					.mouseout(function(){
						$('#zoomImg .thumbnail .owl-nav').css('display','none');
					});

				$('#zoomImg .thumbnail .owl-nav .owl-prev')
					.mouseover(function(){
						$('#zoomImg .thumbnail .owl-nav').css('display','block');
						flagThumbHover = false;
					})
					.mouseout(function(){
						$('#zoomImg .thumbnail .owl-nav').css('display','none');
					});
			});

		$('#zoomImg .thumbnail .owl-nav .owl-next')
			.mouseover(function(){
				$('#zoomImg .thumbnail .owl-nav').css('display','block');
				flagThumbHover = false;
			})
			.mouseout(function(){
				$('#zoomImg .thumbnail .owl-nav').css('display','none');
			});

		$('#zoomImg .thumbnail .owl-nav .owl-prev')
			.mouseover(function(){
				$('#zoomImg .thumbnail .owl-nav').css('display','block');
				flagThumbHover = false;
			})
			.mouseout(function(){
				$('#zoomImg .thumbnail .owl-nav').css('display','none');
			});
	}
}

// function ThumbImageResize(){
// 	if($('.mfp-img').length > 0){
// 		var p = $('.mfp-img');
// 		var offset = p.offset();
// 		$('.regular.slider.thumbnail').css('top',offset.top - 698);

// 		if($( window ).width() <= 1199){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 730);
// 		}
// 		if($( window ).width() <= 991){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 1530);
// 		}
// 		if($( window ).width() <= 740){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 1515);
// 		}
// 		if($( window ).width() <= 720){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 1500);
// 		}
// 		if($( window ).width() <= 700){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 1480);
// 		}
// 		if($( window ).width() <= 670){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 1440);
// 		}
// 		if($( window ).width() <= 660){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 1430);
// 		}
// 		if($( window ).width() <= 650){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 1400);
// 		}
// 		if($( window ).width() <= 580){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 1380);
// 		}
// 		if($( window ).width() <= 568){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 1300);
// 		}
// 		if($( window ).width() <= 480){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 1280);
// 		}
// 		if($( window ).width() <= 430){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 1260);
// 		}
// 		if($( window ).width() <= 414){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 1240);
// 		}
// 		if($( window ).width() <= 384){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 1300);
// 		}
// 		if($( window ).width() <= 360){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 1320);
// 		}
// 		if($( window ).width() <= 345){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 1340);
// 		}
// 		if($( window ).width() <= 335){
// 			$('.regular.slider.thumbnail').css('top',offset.top - 1400);
// 		}
// 	}
// }

function SliderCarousel(){
	var owl = $('.owl-carousel');
	var owlThumbnail = $('.owl-carousel.thumbnail');

	owlThumbnail.owlCarousel({
		margin: 10,
		loop: false,
		touchDrag  : false,
        mouseDrag  : false,
		// autoplay:true,
		// autoplayTimeout:3000,
		// autoplayHoverPause:true,
		// smartSpeed:1000,
		items: 7,
		nav: true,
	});
	
	owlThumbnail.on('mousewheel', '.owl-stage', function (e) {
		if (e.deltaY>0) {
			owlThumbnail.trigger('next.owl');
		} else {
			owlThumbnail.trigger('prev.owl');
		}
		e.preventDefault();
	});

	owl.owlCarousel({
		margin: 10,
		loop: true,
		autoplay:true,
		autoplayTimeout:3000,
		autoplayHoverPause:true,
		smartSpeed:1000,
		items: 1,
		nav: true,
	});
}

// function SelectThumbnail(){
// 	$('#zoomImg .owl-carousel.thumbnail .owl-item img').click(function(){
// 		$('#zoomImg .owl-carousel.thumbnail .owl-item img').removeClass('thumbnail-focus');
// 		$(this).addClass('thumbnail-focus');
// 		$('.owl-carousel .main-image').attr('src',$(this).attr('src'));
// 	});
// }